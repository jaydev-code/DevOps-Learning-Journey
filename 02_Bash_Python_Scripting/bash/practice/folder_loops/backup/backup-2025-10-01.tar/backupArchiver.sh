#!/bin/bash

backup="backup-$( date +%Y-%m-%d).tar"
tar -cf "$backup" .


