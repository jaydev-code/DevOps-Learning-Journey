#!/bin/bash


read -p "ente first number " num1 
read -p "enter second number " num2
sum=$(( $num1 + $num2 ))
echo "$sum"

